﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Verse;

namespace RunAndGun
{
    class CompProperties_RunAndGun : CompProperties
    {
        public CompProperties_RunAndGun()
        {
            compClass = typeof(CompRunAndGun);
        }
    }
}
