﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Verse;

namespace RunAndGun
{
    public class DefModExtension_SettingDefaults : DefModExtension
    {
        public bool weaponForbidden = false;
    }
}
