﻿using Verse;

namespace LifeSupport {
    public class CompProperties_LifeSupport : CompProperties {
        public CompProperties_LifeSupport() {
            compClass = typeof(LifeSupportComp);
        }
    }
}
