# Bionic icons

Adds icons for body part boxes.
