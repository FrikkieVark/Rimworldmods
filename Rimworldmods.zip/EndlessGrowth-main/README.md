

# EndlessGrowth for Rimworld !
[![License: MIT][license]][MIT]

This mod lets your colonist scales higher than level 20, making them grow endlessly.

Steam Workshop Page : https://steamcommunity.com/sharedfiles/filedetails/?id=2894401734


[license]: https://img.shields.io/github/license/Slime-Senpai/EndlessGrowth

[MIT]: https://opensource.org/licenses/MIT
