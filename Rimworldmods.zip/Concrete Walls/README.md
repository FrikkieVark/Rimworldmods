# ConcreteWalls mod for RimWorld
[![target RimWorld version](https://img.shields.io/github/release/porohkun/ConcreteWalls.svg?style=flat-square&label=RimWorld)](https://github.com/porohkun/ConcreteWalls/releases)

Adds really strong walls, doors and embrasures.
And Concrete slabs for building this walls and other stone stuff from vanilla and other mods.
And one research for crafting it in Electric smelter.

Concrete wall about 5 times stronger than a stone wall.

Steam workshop link: http://steamcommunity.com/sharedfiles/filedetails/?id=795240891
