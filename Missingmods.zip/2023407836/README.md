# StabilizeHere mod for RimWorld

Lets you tend to downed pawns right where they are instead of taking them to beds.
A true lifesaver :)

Steam workshop: https://steamcommunity.com/sharedfiles/filedetails/?id=2023407836
