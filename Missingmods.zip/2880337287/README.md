# CM_Go_To_Sleep
 Rimworld mod that adds the ability to command a colonist to sleep outside of scheduled sleeping hours.
